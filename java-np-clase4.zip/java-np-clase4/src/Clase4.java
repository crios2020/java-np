
public class Clase4 {

	public static void main(String[] args) {
		// Clase 04 - Estructura for

		System.out.println("-- Inicio Estructura While --");
		int a=1;
		while(a<=10) {
			System.out.println(a);
			a++;
		}
		System.out.println("-- Fin Estructura While --");
		System.out.println(a);

		System.out.println("-- Inicio de Estructura For --");
		for(int i=1; i<=10 ; i++ ) {
			System.out.println(i);
		}
		System.out.println("-- Fin de Estructura For --");
		//System.out.println(i); //La variable de control se destruye
		
		//Recorrido con variables globales
		for(a=1; a<=10; a++) {
			System.out.println(a);
		}
		System.out.println(a);
		
		//Recorrido con varias variables de control
		for(int i=1, j=5; i<=5 && j<=30; i++,j+=2) {			
			System.out.println(i+" "+j);
		}
		
		for(int i=1, j=5; i<=5 || j<=30; i++,j+=2) {			
			System.out.println(i+" "+j);
		}

//		Ejercicio 1
//		Imprimir los números del 1 al 10 uno abajo del otro.
		System.out.println("Ejercicio 1");
		for(int i=1; i<=10 ; i++ ) {
			System.out.println(i);
		} 
			
//		Ejercicio 2
//		Imprimir los números del 1 al 10 salteando de a dos uno abajo del otro.
		System.out.println("Ejercicio 2");
		for(int i=1; i<=10 ; i+=2 ) {
			System.out.println(i);
		} 
		
//		Ejercicio 3
//		Imprimir los números del 10 al 1 uno abajo del otro.
		System.out.println("Ejercicio 3");
		for(int i=10; i>=1 ; i-- ) {
			System.out.println(i);
		} 
		
//		Ejercicio 4
//		Imprimir la suma de los números impares del 1 al 10.
		System.out.println("Ejercicio 4");
		int total=0;
		for(int i=1; i<=10; i+=2) {
			total+=i;
		}
		System.out.println("Total: "+total);
		
		total=0;
		for(int i=1; i<=10; i++) {
			if(i%2!=0) total+=i;
		}
		System.out.println("Total: "+total);
		
//		Ejercicio 5
//		Mostrar la suma de la multiplicación de los números del 1 al 5 con la suma de los números del 1 al 5.
		
//		Mostrar la suma de 
		//la multiplicación de los números del 1 al 5
		//  +
		//la suma de los números del 1 al 5.
//		
		System.out.println("Ejercicio 5");
		int suma=0;
		int multi=1;
		for(int i=1; i<=5; i++) {
			suma+=i;
			multi*=i;
		}
		int resultado=suma+multi;
		System.out.println("Total: "+resultado);
		System.out.println("Total: "+(suma+multi));
		
//		Ejercicio 6
//		Imprimir la siguiente figura utilizando la estructura for:
//		@
//		@
//		@
//		@
		System.out.println("Ejercicio 6");
//		System.out.println("@");
//		System.out.println("@");
//		System.out.println("@");
//		System.out.println("@");
//		System.out.println("@");
		for(int i=1; i<=5; i++) {
			System.out.println("@");
		}
		
//		Ejercicio 7
//		Imprimir la siguiente figura utilizando la estructura for:
//		@
//		@@
//		@
//		@@
//		@
		System.out.println("Ejercicio 7");
		for(int i=1; i<=5; i++) {
			if(i%2==0) {
				System.out.println("@@");
			}else {
				System.out.println("@");
			}
		}
		
		// @@@@@
		for(int i=1; i<=5; i++) {
			System.out.print("@");
		}
		System.out.println();
		
		// @@@@@
		// @@@@@
		// @@@@@
		// @@@@@
		// @@@@@
		for(int j=1; j<=5; j++) {
			for(int i=1; i<=5; i++) {
				System.out.print("@");
			}
			System.out.println();
		}
		
		
	//   i 1 2 3 4 5  j
		// @ @ @ @ @  1
		
		// @ @ @ @ @  2
		
		// @ @ @ @ @  3
		
		// @ @ @ @ @  4
		
		// @ @ @ @ @  5
		
		
		// 1 2 3 4 5     i		j
		// @					1 - 1
		
		// @ @					1 - 2
		
		// @ @ @				1 - 3
		
		// @ @ @ @				1 - 4
		
		// @ @ @ @ @			1 - 5
		
		
//		Ejercicio 8
//		Imprimir la siguiente figura utilizando la estructura for:
//		@
//		@@
//		@@@
//		@@@@
//		@@@@@
		System.out.println("Ejercicio 8");
		for(int j=1; j<=5; j++) {
			for(int i=1; i<=j; i++) {
				System.out.print("@");
			}
			System.out.println();
		}
		
		
//		Ejercicio 9
//		Imprimir la siguiente figura utilizando la estructura for:
//		@@@@@
//		@@@@
//		@@@
//		@@
//		@
		System.out.println("Ejercicio 9");
		for(int j=5; j>=1; j--) {
			for(int i=1; i<=j; i++) {
				System.out.print("@");
			}
			System.out.println();
		}
		
//		Ejercicio 10
//		Imprimir la siguiente figura utilizando la estructura for:
//		@
//		@@
//		@@@
//		@@@@
//		@@@@@	
//		@@@@
//		@@@
//		@@
//		@
		System.out.println("Ejercicio 10");
		for(int j=1; j<=5; j++) {
			for(int i=1; i<=j; i++) {
				System.out.print("@");
			}
			System.out.println();
		}
		for(int j=5; j>=1; j--) {
			for(int i=1; i<=j; i++) {
				System.out.print("@");
			}
			System.out.println();
		}
		
		//Modo muy complejo, no recomendado 
		for(int i=1; i<=10; i++) {
			if(i<=5) {
				for(int j=1; j<=i; j++) {
					System.out.print("@");
				}
			}else {
				for(int j=10-i; j>=1; j--) {
					System.out.print("@");
				}
			}
			System.out.println();
		}
		
//		Ejercicio 11
//		Imprimir la siguiente figura utilizando la estructura for:
//		@@@@@
//		@@@
//		@
//		@@@
//		@@@@@
		
		
	}

}

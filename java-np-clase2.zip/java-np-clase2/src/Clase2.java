import java.time.LocalDateTime;

public class Clase2 {

	public static void main(String[] args) {

		// Operadores Lógicos

		// Operador Nombre
		// && (Shift 6) AND
		// || (altGR 1) OR
		// == EQUALS
		// != NOT EQUALS
		// ! NOT
		// < <= > >= Comparación

		// Tabla de Verdad

		// X Y OR AND
		// F F F F
		// F V V F
		// V F V F
		// V V V V

		// Clase 2
		boolean log1 = true;
		boolean log2 = false;

		System.out.println(log1 || log2);

		// Para aprobar hay que hacer un TP o rendir examen
		boolean tp = true;
		boolean examen = true;
		System.out.println(tp || examen);

		// Para aprobar hay que hacer un TP y rendir examen
		System.out.println(tp && examen);

		int nro1 = 5;
		int nro2 = 7;

		System.out.println(nro1 == nro2);
		System.out.println(nro1 != nro2);
		System.out.println(nro1 <= nro2);
		System.out.println(!log1);

		// Para que te otorguen el credito, necesito tener garantia hipotecaria y sueldo
		// mayor a 300000
		// y acreditar antiguedad laboral >5 años o sino hay antiguedad ser
		// monotributista categoria f.

		boolean garantia = true;
		int sueldo = 320000;
		int antiguedadLaboral = 7;
		boolean monotributistaF = false;

		System.out.println(garantia && sueldo > 300000 && (antiguedadLaboral > 5 || monotributistaF));

		// Estructura condicional if
		if (!log1) {
			System.out.println("Verdad 1");
			// varias sentencias
			// hacer cosas
			// código indentado
		}

		// System.out.println("Me invitas a un cafe.");
		// System.out.println("Cuanto dinero tenes?");
		// int dinero=new java.util.Scanner(System.in).nextInt(); //ingreso por consola
		// System.out.println(dinero);
		// if(dinero>=2000) {
		// System.out.println("Pedimos dos cafes con leche y medias lunas!!");
		// }

		// Modo Abreviado
		if (log1) System.out.println("Verdad 2");

		// Modo de llaves expandido
		if (log1) 
		{
			System.out.println("Verdad 3");
		}

		if(log1) {
			System.out.println("Verdad 4");
		}
		
		LocalDateTime ldt=LocalDateTime.now();
		System.out.println(ldt);
		
		//días de la semana
		int dia=ldt.getDayOfWeek().getValue();
		System.out.println(dia);
		if(dia==1) System.out.println("Lunes");
		if(dia==2) System.out.println("Martes");
		if(dia==3) System.out.println("Miércoles");
		if(dia==4) System.out.println("Jueves");
		if(dia==5) System.out.println("Viernes");
		if(dia==6) System.out.println("Sábado");
		if(dia==7) System.out.println("Domingo");
				
		//meses del año
		int mes=ldt.getMonthValue();
		System.out.println(mes);
		if(mes==1) System.out.println("Enero");
		if(mes==2) System.out.println("Febrero");
		if(mes==3) System.out.println("Marzo");
		if(mes==4) System.out.println("Abril");
		if(mes==5) System.out.println("Mayo");
		if(mes==6) System.out.println("Junio");
		if(mes==7) System.out.println("Julio");
		if(mes==8) System.out.println("Agosto");
		if(mes==9) System.out.println("Septiembre");
		if(mes==10) System.out.println("Octubre");
		if(mes==11) System.out.println("Noviembre");
		if(mes==12) System.out.println("Diciembre");
		
		//Estructura if else
		if(!log1) {
			System.out.println("Verdad 5");
		}else{
			System.out.println("False 5");
		}
		
//		System.out.println("Me invitas a un cafe.");
//		System.out.println("Cuanto dinero tenes?");
//		int dinero=new java.util.Scanner(System.in).nextInt(); //ingreso por consola
//		System.out.println(dinero);
//		if(dinero>=2000) {
//			System.out.println("Pedimos dos cafes con leche y medias lunas!!");
//		} else {
//			System.out.println("Vamos a la plaza!");
//		}
		
		//Saludo
		System.out.print("Ingrese su nombre: ");
		String nombre=new java.util.Scanner(System.in).nextLine();
		System.out.println("Hola "+nombre);
		
		
		
	}

}

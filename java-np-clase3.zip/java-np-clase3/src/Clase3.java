import java.time.LocalDateTime;
import java.util.Scanner;

public class Clase3 {

	public static void main(String[] args) {
		// Clase 3
		
		LocalDateTime ldt=LocalDateTime.now();
		
		int diaSemana=ldt.getDayOfWeek().getValue();
		System.out.println(diaSemana);
		
		//diaSemana=38;
		
		if(diaSemana==1) System.out.println("Lunes");
		if(diaSemana==2) System.out.println("Martnes");
		if(diaSemana==3) System.out.println("Miércoles");
		if(diaSemana==4) System.out.println("Jueves");
		if(diaSemana==5) System.out.println("Viernes");
		if(diaSemana==6) System.out.println("Sábado");
		if(diaSemana==7) System.out.println("Domingo");
		
		switch(diaSemana) {
			case 1: System.out.println("Lunes"); 		break;
			case 2: System.out.println("Martes"); 		break;
			case 3: System.out.println("Miércoles"); 	break;
			case 4: System.out.println("Jueves"); 		break;
			case 5: System.out.println("Viernes"); 		break;
			case 6: System.out.println("Sábado"); 		break;
			case 7: System.out.println("Domingo"); 		break;
			default: System.out.println("Valor Erroneo!");
		}
		
		//diaSemana=7;
		switch(diaSemana) {
			case 1: case 2: case 3: case 4: case 5:
				System.out.println("Día Laboral, hay que ir a trabajar!");
			break;
			case 6: case 7:
				System.out.println("Fin de semana!");
			break;
			default: System.out.println("Valor Erroneo!");
		}
		
		//diaSemana=38;
		switch(diaSemana) {
			case 1: System.out.println("Lunes");
			case 2: System.out.println("Martes");
			case 3: System.out.println("Miércoles");
			case 4: System.out.println("Jueves");
			case 5: 
				System.out.println("Viernes");
				System.out.println("Día Laboral, hay que ir a trabajar!");
			break;
			case 6: case 7:
				System.out.println("Fin de semana!");
			break;
			default: System.out.println("Valor Erroneo!");
		}
		
		
		//Estructura while
		int a=1;
		System.out.println("-- Inicio de estructura While --");
		while(a<=10) {
			System.out.println(a);
			a++;
		}
		System.out.println("-- Fin de estructura While --");
		System.out.println(a);

		
		//Sensor de lluvia
		//boolean llueve=false;
		//while(!llueve) {
			//lleer el sensor
		//	llueve=true;
		//}
		//bajar toldo
		
		//Modo de uso de llaves expandido
		a=1;
		while(a<=10)
		{
			System.out.println(a);
			a++;
		}
		
		//Modo de uso de llaves abreviado
		a=1;
		while(a<=10) System.out.println(a++);
		
		//Estructura while
		a=23;
		System.out.println("-- Inicio de estructura While --");
		while(a<=10) {
			System.out.println(a);
			a++;
		}
		System.out.println("-- Fin de estructura While --");
		System.out.println(a);
		
		//Estructura Do While
		a=23;
		System.out.println("-- Inicio de estructura do While --");
		do {
			System.out.println(a);
			a++;
		}while(a<=10);
		System.out.println("-- Fin de estructura do While --");
		System.out.println(a);
		
		//loop inifinito
		//a=1;
		//while(true) {
			//System.out.println(a);
		//	a++;
		//}
		
		//loop inifinito
//		a=1;
//		while(a<=10 || true) {
//			System.out.println(a);
//			a++;
//		}
		
		//loop inifinito
//		a=1;
//		while(a<=10 || a>=1) {
//			System.out.println(a);
//			a++;
//		}
		
		//loop inifinito
//		a=1;
//		while(a<=10) {
//			System.out.println(a--);
//			a++;
//		}
		
		//loop inifinito
//		a=1;
//		while(a<=10);
//		{
//			System.out.println(a);
//			a++;
//		}
		
//		Ejercicio 1
//		Imprimir los números del 1 al 10 uno abajo del otro.
		System.out.println("Ejercicio 1");
		a=1;
		while(a<=10) {
			System.out.println(a);
			a++;
		}
		
//		Ejercicio 2
//		Imprimir los números del 1 al 10 salteando de a 2 uno abajo del otro.
		System.out.println("Ejercicio 2");
		a=1;
		while(a<=10) {
			System.out.println(a);
			//a=a+2;
			a+=2;
		}
		
//		Ejercicio 3
//		Imprimir los números del 10 al 1 uno abajo del otro.
		System.out.println("Ejercicio 3");
		a=10;
		while(a>=1) {
			System.out.println(a);
			a--;
		}
		
		System.out.println("Ejercicio 3 Rodrigo");
		a=1;
		while(a<=10) {
			System.out.println(11-a);
			a++;
		}
		
//		Ejercicio 4
//		Imprimir los números del 1 al 10 sin imprimir números 2,5 y 9 uno abajo del otro
//		Requisito: se necesita tener conocimiento del operador AND (&&) y del operador NOT (!=).
		System.out.println("Ejercicio 4");
		a=1;
		while(a<=10) {
			if(a!=2 && a!=5 && a!=9) System.out.println(a);
			a++;
		}
		
//		Ejercicio 5
//		Imprimir los números del 1 al 30 sin imprimir números entre el 10 y el 20 uno abajo del otro
//		Requisito: se necesita tener conocimientos del operador OR (||).
		System.out.println("Ejercicio 5");
		a=1;
		while(a<=30) {
			if(a<=10 || a>=20) System.out.println(a);
			a++;
		}

//		Ejercicio 6
//		Imprimir la suma de los números del 1 al 10.
		System.out.println("Ejercicio 6");
		System.out.println(1+2+3+4+5+6+7+8+9+10);
		
		a=1;
		int total=0;
		while(a<=10) {
			total+=a;
			a++;
		}
		System.out.println("Total: "+total);
		
		//Operador Resto %
		System.out.println(15%2); 		//1
		System.out.println(14%2); 		//0
		System.out.println(-14%2); 		//0
		System.out.println(-15%2); 		//-1
		
//		Ejercicio 7
//		Imprimir la suma de los números pares del 1 al 25
//		Requisito: se necesita tener conocimientos del operador RESTO (%).
		System.out.println("Ejercicio 7");
		a=1;
		total=0;
		while(a<25) {
			if(a%2==0) total+=a;
			a++;
		}
		System.out.println("Total: "+total);
		
//		Ejercicio 8
//		Imprimir la multiplicación de los números impares que se encuentran entre -10 y 10.
		System.out.println("Ejercicio 8");
		a=-10;
		int multiplicador=1;
		while(a<=10) {
			if(a%2!=0) multiplicador*=a;
			a++;
		}
		System.out.println(multiplicador);
		
		//Ejercicio IF
		//Se ingresan tres notas de un alumno, si el promedio es mayor o igual a siete mostrar un mensaje
		//"Promocionado".
		
		int nota1=4;
		int nota2=9;
		int nota3=7;

		System.out.println("Ingrese nota1: ");
		nota1=new Scanner(System.in).nextInt();
		
		System.out.println("Ingrese nota2: ");
		nota2=new Scanner(System.in).nextInt();
		
		System.out.println("Ingrese nota3: ");
		nota3=new Scanner(System.in).nextInt();
		
		int promedio=(nota1+nota2+nota3)/3;
		System.out.println("Promedio de notas: "+promedio);
		if(promedio>=7) System.out.println("Promocionado"); 
		
		
	}

}


public class Clase1 {
	public static void main(String[] args) {
		/*
		 * Curso: 	Java para No Programadores	18hs.
		 * Días:	Sábados 15:00 a 18:00 hs
		 * Profe: 	Carlos Ríos		carlos.rios@educacionit.com
		 * 
		 * Materiales:		alumni.educacionit.com
		 * 					user: email
		 * 					pass: dni
		 * 
		 * Github:	https://github.com/crios2020/java-np
		 * 
		 * Software:	JDK Oracle:		https://www.oracle.com/java/technologies/downloads/		
		 * 				Eclipse IDE:	https://www.eclipse.org/
		 * 
		 * JDK: Java Development Kit (Kit de desarrollo Java)	Oracle-RedHat-IBM-Amazon-Microsoft-Eclipse-Apache
		 * IDE: Integrated Development Eviroment (Entorno de desarrollo Integrado) Eclipse-Nebeans-IntelliJ-VSCode
		 */
		
		// Linea de comentarios
		/* Bloque de comentarios */
		
		System.out.println("Hola Mundo!");	// ; es el terminador de sentencias

		//Lenguaje Case Sensitive
		
		//syso ctrol espacio	atajo de teclado para System.out.println();
		// en netbeans sout	TAB
		
		System.out.println("Hoy es Sábado!");
		System.out.print("1");
		System.out.print("2");
		System.out.print("3");
		System.out.println("4");
		System.out.println("EducaciónIT");
		
		/*
		 * 		Consola de Salida
		 * 
		 * Hola Mundo!
		 * Hoy es Sábado!
		 * 1234
		 * EducaciónIT
		 * 
		 */
		
		//Variables
		
		//Tipo de datos int
		int a;						//Declaración de variable
		a=2;						//Asignación de valor a la variable
		
		int b=4;					//Declaración y asignación de variable
		
		int c=a+b;					// 6
		
		int d=26, e=46, f=65, g=26;	//Declaración y asignación multiple.
		
		System.out.println(a);
		System.out.println("Variable a: "+a);
		System.out.println("a+b="+a+b); 			// a+b=24
		System.out.println("a+b="+(a+b));
		
		//Una variable solo puede ser declarada 1 vez;
		//Una variable puede tener infinitas asignaciones de valor
		
		//int a; //Error variable ya declarada
		a=4;
		System.out.println(a);
		a=16;
		System.out.println(a);
		a=65;
		System.out.println(a);
		a=2;
		
		// Variables String
		String p="Recreo";
		String r="Cafe";
			
		System.out.println(p+r);
		System.out.println(p+" "+r);
		System.out.println(p+" y "+r);
		
		// Variables char
		char x=65;
		System.out.println(x);
		x='m';
		System.out.println(x);
		
		// Variables float 32 bits
		float fl=8.55f;
		System.out.println(fl);
		
		// Variable double 64 bits
		double dl=8.55;
		System.out.println(dl);
		
		fl=10;
		dl=10;
		System.out.println(fl/3);
		System.out.println(dl/3);
		
		fl=100;
		dl=100;
		System.out.println(fl/3);
		System.out.println(dl/3);
		
		fl=1000;
		dl=1000;
		System.out.println(fl/3);
		System.out.println(dl/3);
		
		//Variables boolean
		boolean bo=true;
		System.out.println(bo);
		bo=false;
		System.out.println(bo);
		
		//Operador de asignación =
		int nro1=5;
		int nro2=7;
		System.out.println(nro1);
		System.out.println(nro2);
		
		nro1=nro2;
		// <--
		
		System.out.println(nro1);
		System.out.println(nro2);
		
		//Operadores incrementales
		
		//sumar 1 a la variable		++
		nro1++;					//nro1=nro1+1;
		System.out.println(nro1);
		
		//restar 1 a la variable		--
		nro1--;					//nro1=nro1-1;
		System.out.println(nro1);
		
		//Sumar x a la variable 	+=
		nro1+=5;				//nro1=nro1+5;
		System.out.println(nro1);

		//Restar x a la variable	-=
		nro1-=5;				//nro1=nro1-5;
		System.out.println(nro1);
		
		//Multiplicar x a la variable	*=
		nro1*=5;				//nro1=nro1*5;
		System.out.println(nro1);
		
		//Dividir x la variable			/=
		nro1/=5;
		System.out.println(nro1);
		
		//Precedenncia y procedencia de operadores Unarios ++ --
		System.out.println(nro1++);
		System.out.println(nro1);
		System.out.println(++nro1);
		System.out.println(nro1--);
		System.out.println(--nro1);
		
		//Constantes final
		//Las constanstes,solo pueden tener una asignación de valor en el momento de la
		//declaración
		final double PI=3.14;
		//PI++; //Error no se puede cambiar de valor a una constante.
		System.out.println(PI);
		
		//Operadores Lógicos
		
		// Operador					Nombre
		//		&& (Shift 6)		AND
		//		|| (altGR 1)		OR
		//		==					EQUALS
		//		!= 					NOT EQUALS
		//		!					NOT
		//	< <= > >=				Comparación
		
		// Tabla de Verdad
		
		//		X		Y		OR		AND
		//		F		F		F		F
		//		F		V		V		F
		//		V		F		V		F
		//		V		V		V		V
		
		boolean log1=true;
		boolean log2=false;
		
		System.out.println(log1||log2);		//true
		System.out.println(log1&&log2);		//false
		
		System.out.println(nro1);
		System.out.println(nro1==7);		//true
		System.out.println(nro1==10); 		//false
		System.out.println(nro1!=7); 		//false
		System.out.println(nro1!=10); 		//true
		System.out.println(nro1<=10); 		//true
		System.out.println(nro1>10); 		//false
		
		System.out.println(log1); 			//true
		System.out.println(!log1); 			//false
		System.out.println(!!log1); 		//true
		System.out.println(!!!log1); 		//false
		System.out.println(!!!!log1); 		//true
		
		//TODO Realizar expresiones logicas más grandes
		
		
		
		
	} //end main
}// end class Programa 

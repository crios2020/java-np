import java.time.LocalDateTime;

public class Hoy {
	public static void main(String[] args) {
		LocalDateTime ldt=LocalDateTime.now();
		//System.out.println(ldt);
		int año=ldt.getYear();
		int mes=ldt.getMonth().getValue();
		int dia=ldt.getDayOfMonth();
		int diaSem=ldt.getDayOfWeek().getValue();
		
		String nombreDia="";
		String nombreMes="";
		
		if(diaSem==1) nombreDia="Lunes";
		if(diaSem==2) nombreDia="Martes";
		if(diaSem==3) nombreDia="Miércoles";
		if(diaSem==4) nombreDia="Jueves";
		if(diaSem==5) nombreDia="Viernes";
		if(diaSem==6) nombreDia="Sábado";
		if(diaSem==7) nombreDia="Domingo";
		
		if(mes==1) nombreMes="Enero";
		if(mes==2) nombreMes="Febrero";
		if(mes==3) nombreMes="Marzo";
		if(mes==4) nombreMes="Abril";
		if(mes==5) nombreMes="Mayo";
		if(mes==6) nombreMes="Junio";
		if(mes==7) nombreMes="Julio";
		if(mes==8) nombreMes="Agosto";
		if(mes==9) nombreMes="Septiembre";
		if(mes==10) nombreMes="Octubre";
		if(mes==11) nombreMes="Noviembre";
		if(mes==12) nombreMes="Diciembre";
		
		System.out.println("Hoy es "+nombreDia+" "+dia+" de "+nombreMes+" de "+año);
		
		
		
	}
}


public class IMC {
	
	// Reset
	public static final String ANSI_RESET = "\u001B[0m";
	// Colores de letra
	public static final String ANSI_BLACK = "\u001B[30m";
	public static final String ANSI_RED = "\u001B[31m";
	public static final String ANSI_GREEN = "\u001B[32m";
	public static final String ANSI_YELLOW = "\u001B[33m";
	public static final String ANSI_BLUE = "\u001B[34m";
	public static final String ANSI_PURPLE = "\u001B[35m";
	public static final String ANSI_CYAN = "\u001B[36m";
	public static final String ANSI_WHITE = "\u001B[37m";
	// Colores de fondo
	public static final String ANSI_BLACK_BACKGROUND = "\u001B[40m";
	public static final String ANSI_RED_BACKGROUND = "\u001B[41m";
	public static final String ANSI_GREEN_BACKGROUND = "\u001B[42m";
	public static final String ANSI_YELLOW_BACKGROUND = "\u001B[43m";
	public static final String ANSI_BLUE_BACKGROUND = "\u001B[44m";
	public static final String ANSI_PURPLE_BACKGROUND = "\u001B[45m";
	public static final String ANSI_CYAN_BACKGROUND = "\u001B[46m";
	public static final String ANSI_WHITE_BACKGROUND = "\u001B[47m";
	
	public static void main(String[] args) {
		//Indice de Masa Muscular
		
		//https://tn.com.ar/sociedad/2021/02/08/imc-que-es-y-como-se-calcula/?outputType=amp
		
		/*
			¿Cómo se mide el IMC?
			El índice se calcula teniendo como parámetro el peso de cada individuo y la altura. 
			El resultado que da es el coeficiente ideal que debería tener esa persona para que su peso sea saludable.
			Para eso se divide el peso de cada persona por la altura al cuadrado. A partir de ese cálculo se estima 
			si se está dentro del rango normal o si por el contrario tiene problemas nutricionales.
			Por ejemplo, el indicador que diagnostica el peso correcto oscila entre 18,5 y 24,9. 
			Por debajo de esas cifras hay problemas con la delgadez y por encima puede reflejar inconvenientes de 
			sobrepeso o de obesidad.
			Por ejemplo, si el resultado da 15 o menos, se está ante un cuadro de delgadez muy severa; de 15 a 15.9 
			es delgadez severa y de 16 a 18.4 es delgadez. En la otra dirección, si se está entre 25 y 29.9 se habla 
			de sobrepeso; de 30 a 34.9 de obesidad moderada; de 35 a 39.9 de un cuadro de obesidad severa y 40 o 
			más ya es obesidad mórbida.
			
			
			Analisis:
				Ingreso de datos: peso y altura.
				
				Calculo IMC: peso / altura^2
				
				Salida de datos:
						imprimir IMC
						imprimir Situación:
									IMC < 15: 				"delgadez muy severa"
									IMC >=15 && IMC < 16: 	"delgadez severa"
									IMC >=16 && IMC < 18,5:	"delgadez"
									IMC >=18,5 && IMC < 25:	"peso normal"
									IMC >=25 && IMC < 30:	"sobrepeso"
									IMC >=30 && IMC < 35:	"obesidad moderada"
									IMC >=35 && IMC < 40:	"obesidad severa"
									IMC >40:				"obesidad mórbida"	
		 */
		
		System.out.println(ANSI_GREEN);
		System.out.println("***************************************************************************");
		System.out.println("*             Calculo de Indice de Masa Corporal IMC                      *");
		System.out.println("*             Uso en personas mayores de edad                             *");
		System.out.println("***************************************************************************");
		System.out.println(ANSI_CYAN);
		Hoy.main(null);
		System.out.println();
		System.out.print("Ingrese su peso en kilogramos: ");
		int peso=new java.util.Scanner(System.in).nextInt();
		System.out.print("Ingrese su altura en centimetros: ");
		int altura=new java.util.Scanner(System.in).nextInt();
		
		double imc=peso/Math.pow((double)altura/100, 2);
		
		System.out.println("Su indice de masa muscular es: "+new java.text.DecimalFormat("###.00").format(imc));
		
		System.out.print("Usted tiene una situación de ");
		if(imc<15)					System.out.print(ANSI_RED+"delgadez muy severa");
		if(imc>=15 && imc<16)		System.out.print(ANSI_RED+"delgadez severa");
		if(imc>=16 && imc<18.5)		System.out.print(ANSI_GREEN+"delgadez");
		if(imc>=18.5 && imc<25)		System.out.print(ANSI_GREEN+"peso normal");
		if(imc>=25 && imc<30) 		System.out.print(ANSI_GREEN+"sobrepeso");
		if(imc>=30 && imc<35)		System.out.print(ANSI_RED+"obesidad moderada");
		if(imc>=35 && imc<40)		System.out.print(ANSI_RED+"obesidad severa");
		if(imc>=40)					System.out.print(ANSI_RED+"obesidad mórbida");
		System.out.println();
		System.out.println(ANSI_YELLOW+"Gracias por utilizar nuestro servicio!");
		System.out.println(ANSI_RESET);

	}
}


public class Login {

	// Reset
	public static final String ANSI_RESET = "\u001B[0m";
	// Colores de letra
	public static final String ANSI_BLACK = "\u001B[30m";
	public static final String ANSI_RED = "\u001B[31m";
	public static final String ANSI_GREEN = "\u001B[32m";
	public static final String ANSI_YELLOW = "\u001B[33m";
	public static final String ANSI_BLUE = "\u001B[34m";
	public static final String ANSI_PURPLE = "\u001B[35m";
	public static final String ANSI_CYAN = "\u001B[36m";
	public static final String ANSI_WHITE = "\u001B[37m";
	// Colores de fondo
	public static final String ANSI_BLACK_BACKGROUND = "\u001B[40m";
	public static final String ANSI_RED_BACKGROUND = "\u001B[41m";
	public static final String ANSI_GREEN_BACKGROUND = "\u001B[42m";
	public static final String ANSI_YELLOW_BACKGROUND = "\u001B[43m";
	public static final String ANSI_BLUE_BACKGROUND = "\u001B[44m";
	public static final String ANSI_PURPLE_BACKGROUND = "\u001B[45m";
	public static final String ANSI_CYAN_BACKGROUND = "\u001B[46m";
	public static final String ANSI_WHITE_BACKGROUND = "\u001B[47m";

	public static void main(String[] args) {
		/*
		 * Ingresar un String con el nombre de usuario y otro String con el password Si
		 * el usuario es 'root' y la clave es '123' informar 'Bienvenido Usuario' Si el
		 * usuario es 'root' pero la clave no es '123' informar 'Password Incorrecta' Si
		 * el usuario no es 'root' informar 'Usuario Incorrecto'
		 */
		System.out.println(ANSI_GREEN);
		System.out.println();
		System.out.println("*************************************************************");
		System.out.println("*              BIENVENIDOS AL SISTEMA                       *");
		System.out.println("*************************************************************");
		System.out.println();
		System.out.println();
		System.out.print("Ingrese su nombre de Usuario: ");
		String user=new java.util.Scanner(System.in).nextLine();
		System.out.print("Ingrese su clave: ");
		String pass=new java.util.Scanner(System.in).nextLine();
		
		//System.out.println(user+" "+pass);
		
//		if(user.equals("root")) {
//			if(pass.equals("123")) {
//				System.out.println("Bienvenido al Sistema!");
//				Hoy.main(null);   //Ejecutamos el programa main!
//			} else {
//				System.out.println(ANSI_RED+"Clave Incorrecta!");
//			}
//		} else {
//			System.out.println(ANSI_RED+"Usuario Incorrecto!");
//		}
		
		if(user.equals("root") && pass.equals("123")) {
			System.out.println("Bienvenido al Sistema!");
			Hoy.main(null);   //Ejecutamos el programa main!
		}
		if(user.equals("root") && !pass.equals("123"))	System.out.println(ANSI_RED+"Clave Incorrecta!");
		if(!user.equals("root"))						System.out.println(ANSI_RED+"Usuario Incorrecto!");
		
		System.out.println(ANSI_RESET);
	}
}
